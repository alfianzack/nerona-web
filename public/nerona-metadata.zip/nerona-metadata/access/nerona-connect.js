/**
 * Jembatan penyambungan akun — HANYA berjalan di halaman nerona-web.
 *
 * Sengaja BUKAN bagian dari entri content_scripts marketplace: kelima belas
 * skrip marketplace tidak punya urusan berjalan di dasbor kita sendiri, dan
 * menjalankannya di sana cuma menambah permukaan galat.
 *
 * Kenapa postMessage aman di sini: token dilewatkan di halaman yang
 * penggunanya SUDAH login. Siapa pun yang bisa menjalankan skrip di halaman itu
 * sudah memegang cookie sesinya, jadi tidak ada kemampuan baru yang diberikan.
 * Karena itu origin pengirim dikunci — halaman marketplace mana pun tidak boleh
 * ikut bicara.
 */
(function () {
  const ASAL = location.origin;

  function versi() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (_e) {
      return "?";
    }
  }

  function kirim(pesan) {
    window.postMessage({ source: "nerona-ext", ...pesan }, ASAL);
  }

  function umumkan() {
    kirim({ type: "HADIR", version: versi() });
  }

  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.origin !== ASAL) return;
    const data = event.data;
    if (!data || data.source !== "nerona-web") return;

    // Dasbor menyapa saat pendengarnya siap; kita mungkin sudah mengumumkan
    // diri sebelum React sempat memasangnya.
    if (data.type === "HALO") {
      umumkan();
      return;
    }

    if (data.type !== "TOKEN") return;
    const token = String(data.token || "").trim();
    if (!token) {
      kirim({ type: "GAGAL", pesan: "Token kosong." });
      return;
    }

    // Dicek eksplisit (bukan cuma diserahkan ke catch di bawah): kalau salah
    // satu skrip access/*.js gagal dimuat, memanggil metodenya langsung
    // melempar TypeError generik ("Cannot read properties of undefined")
    // yang tidak bisa ditindaklanjuti pengguna. Pesan ini bisa.
    if (!globalThis.NeronaWebClient?.setToken || !globalThis.NeronaWebClient?.fetchAccountState) {
      kirim({ type: "GAGAL", pesan: "Modul akun tidak dimuat. Muat ulang ekstensi." });
      return;
    }

    try {
      await globalThis.NeronaWebClient.setToken(token);

      // Dipisah dari try/catch utama dengan sengaja: pada titik ini token
      // SUDAH tersimpan lewat setToken di atas. Kalau clearAccessCache()
      // melempar (mis. "Extension context invalidated" saat ekstensi baru
      // saja di-reload sementara instance content script lama masih hidup),
      // itu tidak boleh membatalkan verifikasi token di bawah dan membuat
      // pengguna dikira GAGAL tersambung padahal tokennya valid. Akibat
      // terburuk yang boleh terjadi hanyalah cache basi sampai 15 menit.
      try {
        await globalThis.NeronaAccess?.clearAccessCache?.();
      } catch (_e) {
        /* diabaikan — lihat penjelasan di atas */
      }

      const state = await globalThis.NeronaWebClient.fetchAccountState(token);
      if (state?.ok) {
        kirim({ type: "TERSAMBUNG", email: state.email || "" });
      } else {
        kirim({ type: "GAGAL", pesan: "Server menolak token yang baru dibuat." });
      }
    } catch (e) {
      kirim({ type: "GAGAL", pesan: String(e?.message || e) });
    }
  });

  umumkan();
})();
