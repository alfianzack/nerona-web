/**
 * Klien nerona-web — sumber akses/akun (menggantikan Google Sheet).
 * Memanggil GET {neronaWebBaseUrl}/api/extension/me dengan Bearer token
 * dan mengembalikan payload dalam bentuk yang sama seperti access.js lama:
 * { ok, plan, validUntil, marketplaces: string[], rejectAnalyzer, pointsBalance, email, model }
 */
(function () {
  const TOKEN_KEY = "neronaToken";

  function baseUrl() {
    const u = String(globalThis.NERONA_ACCESS_CONFIG?.neronaWebBaseUrl || "").trim();
    return u.replace(/\/+$/, "");
  }

  /**
   * Sejak Chrome 85, fetch() di dalam content script tunduk pada CORS milik HALAMAN,
   * jadi panggilan ke nerona-web dari halaman marketplace akan diblokir. Service
   * worker (background) tidak kena aturan itu karena memakai host_permissions
   * ekstensi, jadi content script menitipkan request lewat NERONA_PROXY_FETCH.
   *
   * File ini dimuat di TIGA konteks: service worker (importScripts di background.js),
   * halaman popup, dan content script. Dua yang pertama boleh fetch langsung.
   */
  function canFetchCrossOriginDirectly() {
    if (typeof window === "undefined") return true; // service worker
    try {
      return String(location?.protocol || "") === "chrome-extension:"; // popup/options
    } catch (_e) {
      return false;
    }
  }

  function runtimeApi() {
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) return chrome.runtime;
      if (typeof browser !== "undefined" && browser.runtime?.sendMessage) return browser.runtime;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  function parseJson(text) {
    try {
      return JSON.parse(String(text || ""));
    } catch (_e) {
      return null;
    }
  }

  function fetchViaBackground(url, init) {
    return new Promise((resolve) => {
      const rt = runtimeApi();
      if (!rt) {
        resolve({ ok: false, status: 0, data: null });
        return;
      }
      let settled = false;
      const done = (value) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      try {
        rt.sendMessage(
          {
            type: "NERONA_PROXY_FETCH",
            request: {
              url,
              method: init?.method || "GET",
              headers: init?.headers || {},
              body: init?.body
            }
          },
          (response) => {
            if (rt.lastError || !response) {
              done({ ok: false, status: 0, data: null });
              return;
            }
            done({
              ok: Boolean(response.ok),
              status: Number(response.status || 0),
              data: parseJson(response.text)
            });
          }
        );
      } catch (_e) {
        done({ ok: false, status: 0, data: null });
      }
    });
  }

  /** Satu pintu request JSON. status 0 = gagal jaringan / proxy tidak tersedia. */
  async function requestJson(url, init) {
    if (!canFetchCrossOriginDirectly()) return fetchViaBackground(url, init);
    let res;
    try {
      res = await fetch(url, init);
    } catch (_e) {
      return { ok: false, status: 0, data: null };
    }
    const text = await res.text().catch(() => "");
    return { ok: res.ok, status: res.status, data: parseJson(text) };
  }

  function storageLocal() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
      if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  async function getToken() {
    const storage = storageLocal();
    if (!storage) return "";
    const data = await storage.get([TOKEN_KEY]);
    return String(data[TOKEN_KEY] || "").trim();
  }

  async function setToken(token) {
    const storage = storageLocal();
    if (!storage) return;
    await storage.set({ [TOKEN_KEY]: String(token || "").trim() });
  }

  // Returns the same shape the extension's access layer expects:
  // { ok, plan, validUntil, marketplaces: string[], rejectAnalyzer, pointsBalance, email, model }
  async function fetchAccountState(token) {
    const t = String(token || "").trim() || (await getToken());
    if (!t) return { ok: false, error: "missing_license" };
    const base = baseUrl();
    if (!base) return { ok: false, error: "server_not_configured" };
    const res = await requestJson(`${base}/api/extension/me`, {
      headers: { Authorization: `Bearer ${t}`, Accept: "application/json" }
    });
    if (res.status === 401) return { ok: false, error: "invalid_key" };
    if (!res.ok) return { ok: false, error: "network" };
    const acc = res.data?.account;
    if (!acc) return { ok: false, error: "invalid_key" };
    const marketplaces =
      acc.marketplaces === "*" || !acc.marketplaces
        ? [...(globalThis.NeronaAccess?.ALL_MARKETPLACES || [])]
        : String(acc.marketplaces)
            .split(",")
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean);
    return {
      ok: Boolean(acc.active),
      error: acc.active ? undefined : "expired",
      plan: acc.plan || "",
      validUntil: acc.validUntil ? new Date(acc.validUntil).toLocaleDateString("id-ID") : "",
      marketplaces,
      rejectAnalyzer: Boolean(acc.rejectAnalyzer),
      pointsBalance: Number(acc.pointsBalance || 0),
      email: acc.email || "",
      // Model AI yang sedang dipakai server (setelan global admin). Kosong kalau
      // server versi lama belum mengirimnya — UI tinggal menyembunyikan barisnya.
      model: String(res.data?.ai?.model || "")
    };
  }

  // Generates content via the nerona-web structured feature endpoint (metered by tenant points).
  // payload: { feature, marketplace, promptMode, batchIndex, image: { mime, dataBase64 }, contextSnippet, monthsCurrent, monthsNext }
  // Prompts are assembled server-side from these structured inputs.
  // Returns { ok: true, content, usage, pointsBalance } or { ok: false, error, status }.
  async function generateFeature(payload) {
    const t = await getToken();
    if (!t) return { ok: false, error: "missing_license" };
    const base = baseUrl();
    if (!base) return { ok: false, error: "server_not_configured" };
    const res = await requestJson(`${base}/api/extension/generate`, {
      method: "POST",
      headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload)
    });
    if (res.status === 0) return { ok: false, error: "network" };
    const data = res.data;
    if (!res.ok || !data?.ok) {
      return {
        ok: false,
        error:
          data?.error ||
          (res.status === 401
            ? "unauthorized"
            : res.status === 402
            ? "no_points"
            : res.status === 403
            ? "inactive"
            : res.status === 413
            ? "payload_too_large"
            : "ai_error"),
        status: res.status
      };
    }
    return { ok: true, content: data.content, usage: data.usage, pointsBalance: data.pointsBalance };
  }

  globalThis.NeronaWebClient = { getToken, setToken, fetchAccountState, generateFeature };
})();
