globalThis.__NERONA_runSafe__("marketplace-canva", function () {
  const mx = globalThis.__NERONA_MX_SELECTORS__;
  if (!mx || typeof mx !== "object") return;
  const stock = globalThis.__NERONA_STOCK_LIKE_SELECTORS__;
  mx.canva = stock && typeof stock === "object" ? stock : { title: [], description: [], keywords: [] };
});
