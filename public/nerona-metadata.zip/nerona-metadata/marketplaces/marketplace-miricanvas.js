globalThis.__NERONA_runSafe__("marketplace-miricanvas", function () {
  const mx = globalThis.__NERONA_MX_SELECTORS__;
  if (!mx || typeof mx !== "object") return;

  const stock = globalThis.__NERONA_STOCK_LIKE_SELECTORS__;
  const uniq = (arr) =>
    [...new Set((arr || []).filter((s) => typeof s === "string" && s.trim()))];

  mx.miricanvas = {
    /** Grid upload DesignHub — seleksi = checkbox CI-66e5 di li TL-ddab. */
    assetGrid: {
      tile: 'li[data-f="TL-ddab"]',
      card: 'article[data-f="CA-d943"]',
      checkbox: 'input[data-f="CI-66e5"]',
      thumbnail: 'img[data-f="CT-dbbf"]',
      thumbWrap: '[data-f="CT-5090"]',
      fileName: 'span[data-f="CF-3d96"]'
    },
    title: uniq([
      'textarea[data-f="DT-9450"]',
      ...(stock?.title || []),
      'textarea[placeholder*="Multiple names" i]',
      'textarea[placeholder*="name" i]',
      'input[placeholder*="name" i]',
      'input[name*="design" i]',
      'input[id*="design" i]',
      'input[name*="work" i]',
      'input[name*="element" i]',
      '[placeholder*="Element Name" i]',
      '[placeholder*="Title" i]',
      "[placeholder*=제목]",
      "[placeholder*=타이틀]",
      '[aria-label*="Element Name" i]',
      '[aria-label*="Title" i]',
      "[aria-label*=제목]",
      '[data-testid*="title" i]'
    ]),
    description: uniq([
      ...(stock?.description || []),
      'textarea[name*="desc" i]',
      '[placeholder*="Description" i]',
      "[placeholder*=설명]",
      "[placeholder*=상세]",
      '[aria-label*="desc" i]',
      "[aria-label*=설명]"
    ]),
    keywords: uniq([
      'input[data-f="II-b5a4"]',
      '[data-f="IF-add5"] input',
      '[data-f="IK-859d"] input',
      'form[data-f="IF-96d1"] input',
      'textarea[placeholder*="Multiple keywords" i]',
      'textarea[placeholder*="keyword" i]',
      ...(stock?.keywords || []),
      'input[name*="tag" i]',
      'input[name*="hash" i]',
      'textarea[name*="tag" i]',
      'textarea[name*="keyword" i]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="Tag" i]',
      "[placeholder*=태그]",
      "[placeholder*=키워드]",
      "[placeholder*=키 워드]",
      '[aria-label*="tag" i]',
      '[aria-label*="keyword" i]',
      "[aria-label*=태그]",
      '[data-testid*="tag" i]',
      '[data-testid*="keyword" i]'
    ])
  };
});
