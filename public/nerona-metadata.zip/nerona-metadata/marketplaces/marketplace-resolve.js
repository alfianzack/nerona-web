/** Deteksi host contributor + probing DOM untuk beberapa marketplace — aman dari error satu modul lain. */

globalThis.__NERONA_runSafe__("marketplace-resolve", function () {
  /** @type {ReadonlySet<string>} */
  const MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE = new Set([
    "adobe",
    "magnific",
    "shutterstock",
    "canva",
    "miricanvas",
    "designbundle",
    "dreamstime"
  ]);

  globalThis.marketplaceUsesDomFieldProbe = function marketplaceUsesDomFieldProbe(marketplace) {
    return MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE.has(String(marketplace || ""));
  };

  globalThis.resolveQuickGenerateMarketplace = function resolveQuickGenerateMarketplace() {
    const h = (location.hostname || "").toLowerCase();
    const path = (location.pathname || "").toLowerCase();

    if (h === "contributor.stock.adobe.com" || h === "contributors.stock.adobe.com") {
      return { mode: "rows", marketplaceKey: "adobe", aiLabel: "Adobe Stock" };
    }
    if (h === "contributor.magnific.com" || h === "contributors.magnific.com") {
      return { mode: "rows", marketplaceKey: "magnific", aiLabel: "Magnific" };
    }
    if (
      h === "contributors.shutterstock.com" ||
      h === "contributor.shutterstock.com" ||
      h === "submit.shutterstock.com"
    ) {
      return { mode: "rows", marketplaceKey: "shutterstock", aiLabel: "Shutterstock" };
    }
    if (h === "contributors.vecteezy.com") {
      return { mode: "rows", marketplaceKey: "vecteezy", aiLabel: "Vecteezy" };
    }

    if (h === "creator.canva.com" || h === "creators.canva.com") {
      return { mode: "rows", marketplaceKey: "canva", aiLabel: "Canva" };
    }
    if ((h === "www.canva.com" || h === "canva.com") && path.includes("/creators")) {
      return { mode: "rows", marketplaceKey: "canva", aiLabel: "Canva" };
    }

    if (
      h === "submit.dreamstime.com" ||
      (/^submit\./.test(h) && h.endsWith(".dreamstime.com")) ||
      ((h === "www.dreamstime.com" || h === "dreamstime.com") &&
        (path.startsWith("/upload") || path.includes("/upload/")))
    ) {
      return { mode: "rows", marketplaceKey: "dreamstime", aiLabel: "Dreamstime" };
    }

    if (h === "www.designbundles.net" || h === "designbundles.net") {
      if (path.startsWith("/account") || path.startsWith("/seller") || path.startsWith("/vendor")) {
        return { mode: "rows", marketplaceKey: "designbundle", aiLabel: "Design Bundles" };
      }
      return null;
    }

    if (h.endsWith(".miricanvas.com") || h === "miricanvas.com") {
      if (
        /^designhub\./i.test(h) ||
        path.startsWith("/mypage") ||
        path.startsWith("/upload") ||
        path.startsWith("/designhub") ||
        path.startsWith("/page/contributor") ||
        path.startsWith("/contributor") ||
        path.includes("/designhub/") ||
        path.includes("/contributor/")
      ) {
        return { mode: "rows", marketplaceKey: "miricanvas", aiLabel: "Miricanvas" };
      }
      return null;
    }

    return null;
  };

  /** Supaya bisa di-inspect di console bila perlu */
  globalThis.MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE = MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE;
});

if (typeof globalThis.marketplaceUsesDomFieldProbe !== "function") {
  globalThis.marketplaceUsesDomFieldProbe = function () {
    return false;
  };
}
if (typeof globalThis.resolveQuickGenerateMarketplace !== "function") {
  globalThis.resolveQuickGenerateMarketplace = function () {
    return null;
  };
}
if (!globalThis.MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE) {
  globalThis.MARKETPLACE_KEYS_WITH_DOM_FIELD_PROBE = new Set();
}
