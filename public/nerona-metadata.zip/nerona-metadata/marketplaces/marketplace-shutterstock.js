globalThis.__NERONA_runSafe__("marketplace-shutterstock", function () {
  const uniq = (arr) =>
    [...new Set((arr || []).filter((s) => typeof s === "string" && s.trim()))];

  const stock = globalThis.__NERONA_STOCK_LIKE_SELECTORS__;

  globalThis.__NERONA_MX_SELECTORS__.shutterstock = {
    /** Grid portfolio submit.shutterstock.com — terpilih = asset-card aria-checked="true" */
    assetGrid: {
      card: '[data-testid="asset-card"]',
      cardSelected: '[data-testid="asset-card"][aria-checked="true"]',
      checkbox: '[data-testid="asset-checkbox"] input[type="checkbox"]',
      checkboxRoot: '[data-testid="asset-checkbox"]',
      thumbnail: 'img[data-testid^="card-media-"][src], img.MuiCardMedia-img[src]'
    },
    title: uniq([
      '[data-testid="title-input-text"] input',
      '[data-testid="title-input"] input',
      ...(stock?.title || []),
      'input[name*="title"]',
      'input[id*="title"]',
      '[placeholder*="Title" i]',
      '[aria-label*="Title" i]'
    ]),
    description: uniq([
      '[data-testid="description-input-text"] textarea',
      '[data-testid="description-input"] textarea',
      '[data-testid="description-input-text"] input',
      ...(stock?.description || []),
      'textarea[name*="description"]',
      'textarea[id*="description"]',
      '[placeholder*="Description" i]',
      '[aria-label*="Description" i]'
    ]),
    keywords: uniq([
      '[data-testid="keyword-input-text"] input',
      '[data-testid="keyword-input"] input',
      ...(stock?.keywords || []),
      'textarea[name*="keyword"]',
      'input[name*="keyword"]',
      'input[name*="tag"]',
      '[placeholder*="Add keyword" i]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="Tag" i]',
      '[aria-label*="Keyword" i]'
    ])
  };
});
