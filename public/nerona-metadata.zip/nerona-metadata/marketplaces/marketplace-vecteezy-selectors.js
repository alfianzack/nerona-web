globalThis.__NERONA_runSafe__("marketplace-vecteezy-selectors", function () {
  const uniq = (arr) =>
    [...new Set((arr || []).filter((s) => typeof s === "string" && s.trim()))];

  globalThis.__NERONA_MX_SELECTORS__.vecteezy = {
    /** Grid upload — terpilih = [data-testid="resource-card"].is-selected */
    assetGrid: {
      card: '[data-testid="resource-card"]',
      cardSelected: '[data-testid="resource-card"].is-selected',
      preview: '[data-testid="resource-card-preview"]',
      thumbnail: '[data-testid="resource-card-preview"] img[src]',
      title: '[data-testid="resource-title-button"]',
      statusTitle: '[data-testid="resource-status-title"]'
    },
    title: uniq([
      'input[name*="title"]',
      'input[id*="title"]',
      'input[placeholder*="min 3 words" i]',
      '[aria-label*="Title" i]',
      '[placeholder*="Title" i]'
    ]),
    description: uniq([
      'textarea[name*="description"]',
      'textarea[id*="description"]',
      '[placeholder*="Description" i]'
    ]),
    keywords: uniq([
      'ul[data-testid="tags-list"] input',
      'textarea[placeholder*="comma separated" i]',
      'textarea[placeholder*="min 5" i]',
      'input[placeholder*="comma separated" i]',
      'input[placeholder*="min 5" i]',
      '[contenteditable="true"][aria-label*="keyword" i]',
      'input[name*="keyword"]',
      'textarea[name*="keyword"]',
      'input[name*="tag"]',
      '[aria-label*="Keywords" i]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="Tag" i]'
    ])
  };
});
