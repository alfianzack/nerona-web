const statusEl = document.getElementById("status");
const neronaTokenEl = document.getElementById("neronaToken");
const connectAccountBtn = document.getElementById("connectAccountBtn");
const accountStatusEl = document.getElementById("accountStatus");

/** chrome.storage.local — Firefox MV3 memakai browser.storage.local */
function extensionStorageLocal() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
    if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
  } catch (_e) {
    /* ignore */
  }
  return null;
}

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#fca5a5" : "#93c5fd";
}

function setAccountStatus(message, state = "") {
  if (!accountStatusEl) return;
  accountStatusEl.textContent = message;
  accountStatusEl.style.color =
    state === "ok" ? "#86efac" : state === "error" ? "#fca5a5" : "";
}

const ACCOUNT_ERROR_MESSAGES = {
  invalid_key: "Token tidak valid.",
  expired: "Paket berakhir.",
  missing_license: "Token belum diisi.",
  network: "Tidak dapat terhubung ke nerona-web.",
  server_not_configured: "URL nerona-web belum diatur."
};

/**
 * Beberapa baris, bukan satu kalimat panjang: status, paket & masa aktif, model AI,
 * lalu saldo. Dirender lewat textContent + `white-space: pre-line` di CSS — bukan
 * innerHTML, karena nama paket, tanggal, dan nama model datang dari server dan tidak
 * ada alasan menyerahkannya ke parser HTML.
 */
function formatAccountStatusMessage(state) {
  // Server lama tidak mengirim model; barisnya cukup dilewati, bukan ditulis "Model: -".
  const modelLine = state?.model ? `Model: ${state.model}` : "";
  if (state?.ok) {
    const points = Number.isFinite(state.pointsBalance) ? state.pointsBalance : 0;
    const lines = ["✓ Akun aktif"];
    const plan = state.plan ? `Paket ${state.plan}` : "";
    // validUntil kosong berarti tanpa batas, bukan kedaluwarsa — jangan tampilkan
    // "berlaku sampai -" untuk akun yang justru tidak punya tanggal akhir.
    const until = state.validUntil ? `berlaku sampai ${state.validUntil}` : "";
    const second = [plan, until].filter(Boolean).join(" · ");
    if (second) lines.push(second);
    if (modelLine) lines.push(modelLine);
    lines.push(`Poin: ${points.toLocaleString("id-ID")}`);
    return lines.join("\n");
  }
  const code = state?.error || "invalid_key";
  const lines = [ACCOUNT_ERROR_MESSAGES[code] || "Akun tidak valid."];
  // Kalau paket berakhir, tanggalnya adalah informasi yang paling dicari.
  if (code === "expired" && state?.validUntil) {
    lines.push(`Berakhir ${state.validUntil}.`);
  }
  if (modelLine) lines.push(modelLine);
  return lines.join("\n");
}

async function refreshAccountStatus(token) {
  if (!globalThis.NeronaWebClient) {
    setAccountStatus("Modul akun tidak dimuat. Muat ulang ekstensi.", "error");
    return { ok: false, error: "invalid_key" };
  }
  setAccountStatus("Memeriksa akun…", "");
  const state = await NeronaWebClient.fetchAccountState(token);
  setAccountStatus(formatAccountStatusMessage(state), state?.ok ? "ok" : "error");
  return state;
}

async function loadAccountUi() {
  if (!globalThis.NeronaWebClient) return;
  const token = await NeronaWebClient.getToken();
  if (neronaTokenEl) neronaTokenEl.value = token || "";
  if (!token) {
    setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "");
    return;
  }
  await refreshAccountStatus(token);
}

connectAccountBtn?.addEventListener("click", async () => {
  try {
    if (!globalThis.NeronaWebClient) {
      throw new Error("Modul akun tidak dimuat. Muat ulang ekstensi.");
    }
    const token = neronaTokenEl?.value?.trim() || "";
    if (!token) {
      setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "error");
      setStatus(ACCOUNT_ERROR_MESSAGES.missing_license, true);
      return;
    }
    connectAccountBtn.disabled = true;
    setAccountStatus("Menyimpan & memeriksa…", "");
    await NeronaWebClient.setToken(token);
    await NeronaAccess?.clearAccessCache?.();
    const state = await refreshAccountStatus(token);
    if (state?.ok) {
      setStatus("Akun tersambung.");
    } else {
      setStatus(formatAccountStatusMessage(state), true);
    }
  } catch (error) {
    setAccountStatus(error.message || "Gagal menyimpan token.", "error");
    setStatus(error.message || "Gagal menyimpan token.", true);
  } finally {
    connectAccountBtn.disabled = false;
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const storage = extensionStorageLocal();
    if (!storage) {
      setStatus(
        "Penyimpanan ekstensi tidak tersedia. Buka pengaturan dari ikon Nerona Metadata di toolbar (jangan drag popup.html ke browser). Pastikan manifest memuat izin \"storage\", lalu muat ulang ekstensi.",
        true
      );
      return;
    }

    await loadAccountUi();
  } catch (err) {
    setStatus(err.message || "Gagal memuat pengaturan AI.", true);
  }
});
